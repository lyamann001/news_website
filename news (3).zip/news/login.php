<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if(isset($_SESSION["user"])){
	header("Location: profile.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/login.css?v="<?=$ver?>>
</head>
<body>
<div id="log">
<h1>Log in to continue</h1>
<p>If you don't have an account: <a href="signup.php">Sign Up</a></p>
<form method="post" action="">
	<input type="text" name="username" placeholder="Username"><br>
	<input type="password" name="password" placeholder="Password"><br>
	<input type="submit" name="login" value="Login">
</form>
</div>
<?php
require_once "connect.php";
if (isset($_POST["login"])){
	$password = hash("sha256", $_POST["password"]);
	$username = $_POST["username"];
	$sqlUser = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
	$resultUser = mysqli_query($con, $sqlUser);
	if(mysqli_num_rows($resultUser) != 0){
		$rowUser = mysqli_fetch_assoc($resultUser);
		$_SESSION["user"] = $rowUser["username"];
		$_SESSION["status"] = $rowUser["status"];
		if($_SESSION["status"] == "admin"){
			header("Location: admin.php");
		}
		else{
			header("Location: profile.php");
		}
	}
	else{
		echo "<p>User name or password is wrong</p>";
	}
}
?>

</body>
</html>