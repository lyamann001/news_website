<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if(!isset($_SESSION["user"])){
	header("Location: login.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>

<!DOCTYPE html>
<html>
<head>
<title>Users List</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/style.css?v="<?=$ver?>>

<style>
img{
	width:50px;
	height:50px;
}
</style>
</head>
<body>

<div id="menu">
<?php
if($_SESSION["status"] == "admin"){
?>
<a class="links" href="admin.php">Admin</a>
<?php
}
else{
?>
<a class="links" href="profile.php">Profile</a>
<?php
}
?>
<a class="links" href="logout.php">Logout</a>
</div>
<?php

require_once "connect.php";
$sqlShowNews = "SELECT * FROM news_content";
$resultShowNews = mysqli_query($con, $sqlShowNews);
?>
<table><tr><th>News</th><th>Header</th><th>News Image</th><th>Content</th><th>View News</th></tr>
<?php
foreach($resultShowNews as $su){
?>
<tr>
	<td><?=$su['id']?></td>
	<td><?=$su['news_header']?></td>
	<td><img src=images/<?=$su['news_img']?>></td>
	<td><?=$su['news_content']?></td>
	<td><a id="vw" href="viewNews.php?id=<?=$su['id']?>">View</a></td></tr>
<?php
}
?>
</table>

</body>
</html>