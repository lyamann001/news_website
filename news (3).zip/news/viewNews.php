<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_GET['id'])){
	header("Location: index.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/viewNews.css?v="<?=$ver?>>
<style>
	table {
	    border-collapse: collapse;
	    width: 100%;
	    box-sizing:border-box;
	}
	td, th {
	    border: 1px solid #dddddd;
	    text-align: left;
	    width:16.6%;
	    padding: 5px;
	}
</style>
</head>
<body>
<div id="menu">
<a href="index.php">Home</a>
<?php
if($_SESSION["status"] != "admin"){
?>
<a href="profile.php">Profile</a>
<?php
}
if($_SESSION["status"] == "admin"){
?>
<a href="admin.php">Admin</a>
<a href="showUsers.php">Show Users</a>
<?php
}
?>
<a href="logout.php">Logout</a>
</div>
<?php
require_once "connect.php";
$newsId = $_GET["id"];

$sqlView = "SELECT * FROM news_content WHERE id='$newsId'";
$resultView = mysqli_query($con,$sqlView);
foreach($resultView as $rw){
?>
<h1><?=$rw['news_header']?></h1>
<img src="images/<?=$rw['news_img']?>">
<p><?=$rw['news_content']?></p>
<?php
}
?>

</body>
</html>