<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if($_SESSION["status"] != "admin"){
	header("Location: profile.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/admin.css?v="<?=$ver?>>
</head>
<body>

<div id="menu">
<a class="links" href="index.php">Home</a>
<a class="links" href="logout.php">Logout</a><br>
</div>
<h1>Admin: <?=$_SESSION["user"] ?></h1>
<p>Add News: <a class="act" href="addNews.php">Add</a></p>
<p>Show Users: <a class="act" href="showUsers.php">Show</a></p>
<p>Show News: <a class="act" href="showNews.php">Show</a></p>

<?php

?>

</body>
</html>