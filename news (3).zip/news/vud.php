<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_GET['opt'])){
	header("Location: index.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/vud.css?v="<?=$ver?>>
</head>
<body>
<div id="menu">
<a href="profile.php" class="links">Profile</a>
<?php
if($_SESSION["status"] == "admin"){
?>
<a href="admin.php" class="links">Admin</a>
<a href="showUsers.php" class="links">Show Users</a>
<?php
}
?>
<a href="logout.php" class="links">Logout</a>
</div>
<?php
require_once "connect.php";
$uId = $_GET["id"];
if($_GET["opt"] == "view"){
$sqlView = "SELECT * FROM users WHERE id='$uId'";
$resultView = mysqli_query($con,$sqlView);
?>
<table><tr><th>Name</th><th>Surname</th><th>Username</th><th>Email</th><th>Status</th></tr><?php
foreach($resultView as $rw){
?>
<tr>
	<td><?=$rw['name']?></td>
	<td><?=$rw['surname']?></td>
	<td><?=$rw['username']?></td>
	<td><?=$rw['email']?></td>
	<td><?=$rw['status']?></td>
</tr>
</table>
<?php
}

}
if($_GET["opt"] == "update"){
$sqlUpdate = "SELECT * FROM users WHERE id='$uId'";
$resultUpdate = mysqli_query($con, $sqlUpdate);
foreach ($resultUpdate as $ru){
?>
<div id="updateForm">
	<form method="post" action="">
	<input type="text" name="name" value="<?=$ru['name']?>" required><br>
	<input type="text" name="surname" value="<?=$ru['surname']?>" required><br>
	<input type="text" name="username" value="<?=$ru['username']?>" required><br>
	<input type="text" name="password" value="<?=$ru['password']?>" required><br>
	<input type="text" name="email" value="<?=$ru['email']?>" required><br>
	<?php
	if($_SESSION["status"] == "admin"){
	?>
	<?php if($ru['status'] == "admin"){?>
	<select name="status">
		<option value="<?=$ru['status']?>"><?=ucfirst($ru['status'])?></option>
		<option value="user">User</option>
	</select>
	<?php } ?>
	<?php if($ru['status'] == "user"){?>
	<select name="status">
		<option value="<?=$ru['status']?>"><?=ucfirst($ru['status'])?></option>
		<option value="admin">Admin</option>
	</select>
	<?php } ?>
	<br>
	<?php } ?>
	<input type="submit" name="update" value="Update"><br>
</form>
</div>
<?php }
if(isset($_POST["update"])){
	$name=$_POST["name"];
	$surname=$_POST["surname"];
	$username=$_POST["username"];
	$password=hash("sha256",$_POST["password"]);
	$email=$_POST["email"];
	$status=$_POST["status"];
	$sqlUpd = "UPDATE users SET name='$name', surname='$surname',username='$username',password='$password',email='$email',status='$status' WHERE id='$uId'";
	mysqli_query($con,$sqlUpd);
	header("Refresh:0");
}
}
if($_GET["opt"] == "delete"){
	$sqlDelete = "DELETE FROM users WHERE id='$uId'";
	$resultDelete = mysqli_query($con, $sqlDelete);
	if($_SESSION["status"] == "admin"){
		header("Location: showUsers.php");
	}
	else{
		header("Location: logout.php");
	}
}

?>

</body>
</html>