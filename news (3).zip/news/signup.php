<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if(isset($_SESSION["user"])){
	header("Location: index.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add New User</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/signup.css?v="<?=$ver?>>
</head>
<body>

<div id="sign">
<h1>Create New Account</h1>
<p>If you have an account: <a href="login.php">Login</a></p>
<form method="post" action="">
	<input type="text" name="name" placeholder="Name" required><br>
	<input type="text" name="surname" placeholder="Surname" required><br>
	<input type="text" name="username" placeholder="Username" required><br>
	<input type="password" name="password" placeholder="Password" required><br>
	<input type="text" name="email" placeholder="Email" required><br>
	<input type="hidden" name="status" value="user">
	<input type="submit" name="addUser" value="Sign Up">
</form>
</div>
<?php
require_once "connect.php";
if(isset($_POST["addUser"])){
	$name = $_POST["name"];
	$surname = $_POST["surname"];
	$username = $_POST["username"];
	$password = hash("sha256", $_POST["password"]);
	$email = $_POST["email"];
	$status = $_POST["status"];
	$sqlCheckUser = "SELECT * FROM users WHERE username='$username' AND email='$email'";
	$resultCheckUser = mysqli_query($con, $sqlCheckUser);
	if(mysqli_num_rows($resultCheckUser) == 0){
		$sqlAddUser = "INSERT INTO users(name,surname,username,password,email,status) VALUES('$name','$surname','$username','$password','$email','$status') ";
		mysqli_query($con,$sqlAddUser);
		$_SESSION["user"] = $username;
		$_SESSION["status"] = $status;
		echo "<p>You successfully signed up</p>";
		header( "refresh:0.5;url=profile.php" );
	}
	else{
		echo "<p>User already exists</p>";
	}
}
?>

</body>
</html>