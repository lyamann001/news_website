<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_GET['opt'])){
	header("Location: index.php");
}
if($_SESSION["status"] != "admin"){
	header("Location: profile.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/vudNews.css?v="<?=$ver?>>
</head>
<body>
<div id="menu">
<a href="profile.php" class="links">Profile</a>
<?php
if($_SESSION["status"] == "admin"){
?>
<a href="admin.php" class="links">Admin</a>
<a href="showUsers.php" class="links">Show Users</a>
<a href="showNews.php" class="links">Show News</a>
<?php
}
?>
<a href="logout.php" class="links">Logout</a>
</div>
<?php
require_once "connect.php";
$uId = $_GET["id"];
if($_GET["opt"] == "view"){
$sqlView = "SELECT * FROM news_content WHERE id='$uId'";
$resultView = mysqli_query($con,$sqlView);
?>
<table><tr><th>News Header</th><th>News Image</th><th>News Content</th></tr><?php
foreach($resultView as $rw){
?>
<tr>
	<td><?=$rw['news_header']?></td>
	<td><img src="images/<?=$rw['news_img']?>"></td>
	<td><?=$rw['news_content']?></td>
</tr>
</table>
<?php
}

}
if($_GET["opt"] == "update"){
$sqlUpdate = "SELECT * FROM news_content WHERE id='$uId'";
$resultUpdate = mysqli_query($con, $sqlUpdate);
foreach ($resultUpdate as $ru){
?>
<div id="updateForm">
	<form method="post" action="">
	<input type="text" name="news_header" value="<?=$ru['news_header']?>" required><br>
	<img src="images/<?=$ru['news_img']?>"><br>
	<input type="file" name="news_img" value="<?=$ru['news_img']?>"><br>
	<textarea name="news_content"><?=$ru['news_content']?></textarea><br>
	<input type="submit" name="update" value="Update"><br>
</form>
</div>
<?php }
if(isset($_POST["update"])){
	$news_header=$_POST["news_header"];
	$news_img=$_POST["news_img"];
	$news_content=$_POST["news_content"];
	if(!empty($news_img)){
		$sqlUpd = "UPDATE news_content SET news_header='$news_header', news_img='$news_img',news_content='$news_content' WHERE id='$uId'";
	}
	else{
		$sqlUpd = "UPDATE news_content SET news_header='$news_header', news_content='$news_content' WHERE id='$uId'";
	}
	mysqli_query($con,$sqlUpd);
	header("Refresh:0");
}
}
if($_GET["opt"] == "delete"){
	$sqlDelete = "DELETE FROM news_content WHERE id='$uId'";
	$resultDelete = mysqli_query($con, $sqlDelete);
	if($_SESSION["status"] == "admin"){
		header("Location: showNews.php");
	}
	else{
		header("Location: logout.php");
	}
}

?>

</body>
</html>