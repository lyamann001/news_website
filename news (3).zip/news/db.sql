create database news_db;

create table users(
id int auto_increment primary key,
name varchar(50) not null,
surname varchar(50) not null,
username varchar(50) not null,
password varchar(100) not null,
email varchar(50) not null,
status varchar(50) not null
);

create table news_content(
id int auto_increment primary key,
news_header varchar(255) not null,
news_img BLOB,
news_content LONGTEXT
);

insert into users(name, surname, username, password, email, status)
values('Laman','Mammadova','laman99','905f096e0c9905cce220a7498b9618d8abbcccd47f5f2fcbd7e5e8e1bb8b389e','laman@gmail.com','admin');

#password is laman12345