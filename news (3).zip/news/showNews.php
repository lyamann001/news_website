<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if($_SESSION["status"] != "admin"){
	header("Location: index.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>

<!DOCTYPE html>
<html>
<head>
<title>News List</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/showNews.css?v="<?=$ver?>>
</head>
<body>

<div id="menu">
<a href="index.php" class="links">Home</a>
<a href="admin.php" class="links">Admin</a>
<a href="logout.php" class="links">Logout</a>
</div>
<a href="<?=$_SERVER['PHP_SELF'];?>?sort=true" class="sort">Sort Asc</a>
<a href="<?=$_SERVER['PHP_SELF'];?>?sort=false" class="sort">Sort Desc</a>

<?php

require_once "connect.php";
if(isset($_GET["sort"])){
	if ($_GET["sort"]=="true"){
		$sqlShowUsers = "SELECT * FROM news_content ORDER BY news_header";
	}
	else if ($_GET["sort"]=="false"){
		$sqlShowUsers = "SELECT * FROM news_content ORDER BY news_header DESC";
	}
}
else{
	$sqlShowUsers="SELECT * FROM news_content";
}

$resultShowUsers = mysqli_query($con, $sqlShowUsers);
?>
<table><tr><th>ID</th><th>News Header</th><th>News Image</th><th>News Content</th><th>Options</th></tr>
<?php
foreach($resultShowUsers as $su){
?>
<tr>
	<td><?=$su['id']?></td>
	<td><?=$su['news_header']?></td>
	<td><img src="images/<?=$su['news_img']?>"></td>
	<td><?=$su['news_content']?></td>
	<td><a href="vudNews.php?id=<?=$su['id']?>&opt=view">view</a> <a href="vudNews.php?id=<?=$su['id']?>&opt=update">update</a> <a href="vudNews.php?id=<?=$su['id']?>&opt=delete">delete</a></td>
</tr>
<?php
}
?>
</table>
</body>
</html>