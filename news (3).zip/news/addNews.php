<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if($_SESSION["status"] != "admin"){
	header("Location: profile.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add New User</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/addNews.css?v="<?=$ver?>>
</head>
<body>

<div id="menu">
<a href="index.php">Home</a>
<a href="admin.php">Admin</a>
<a href="logout.php">Logout</a>
</div>
<h1>Add News</h1>
<div id="addN">
<form method="post" action="">
	<input type="text" name="newsHead" placeholder="News Header" required><br>
	<textarea name="newsCont" placeholder="News Content" required></textarea><br>
	<input type="file" name="newsImg"><br>
	<input type="submit" name="addNews" value="Add">
</form>
</div>
<?php
require_once "connect.php";
if(isset($_POST["addNews"])){
	$head = $_POST["newsHead"];
	$cont = $_POST["newsCont"];
	$newsImg = $_POST["newsImg"];
	$sqlAddNews = "INSERT INTO news_content(news_header,news_img,news_content) VALUES('$head','$newsImg','$cont') ";
	mysqli_query($con,$sqlAddNews);
	echo "<p>News successfully added</p>";
}
?>

</body>
</html>