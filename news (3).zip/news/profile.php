<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if(!isset($_SESSION["user"])){
	header("Location: login.php");
}
if($_SESSION["status"] == "admin"){
	header("Location: admin.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/profile.css?v="<?=$ver?>>
</head>
<body>

<div id="prof">
<a href="index.php">Home</a>
<?php
require_once "connect.php";
$usr=$_SESSION["user"];
$sqlSelectUsers = "SELECT * FROM users WHERE username='$usr'";
$resultSelectUsers = mysqli_query($con, $sqlSelectUsers);
foreach($resultSelectUsers as $su){
?>
	<a href="vud.php?id=<?=$su['id']?>&opt=view">View</a>
	<a href="vud.php?id=<?=$su['id']?>&opt=update">Update</a>
	<a href="vud.php?id=<?=$su['id']?>&opt=delete">Delete</a>
<?php
}
?>
<a href="logout.php">Logout</a>
</div>
<h1>Welcome <?=$_SESSION["user"]?></h1>
<p>You can read daily news from out website</p>


</body>
</html>