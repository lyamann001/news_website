<?php
$server = "localhost";
$user = "root";
$pass = "";
$db = "news_db";

$con = mysqli_connect($server,$user,$pass,$db);
?>