<?php
if(session_status() == PHP_SESSION_NONE) {
    session_start();
}
if($_SESSION["status"] != "admin"){
	header("Location: index.php");
}
$ver=date('YmdHis').rand(1,9999999);
?>

<!DOCTYPE html>
<html>
<head>
<title>Users List</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/showUsers.css?v="<?=$ver?>>
<style>
	/*table {
	    font-family: arial, sans-serif;
	    border-collapse: collapse;
	    width: 100%;
	}
	td, th {
	    border: 1px solid #dddddd;
	    text-align: left;
	    padding: 8px;
	}

	tr:nth-child(even) {
	    background-color: #dddddd;
	}*/
</style>
</head>
<body>

<div id="menu">
<a href="index.php" class="links">Home</a>
<a href="admin.php" class="links">Admin</a>
<a href="logout.php" class="links">Logout</a>
</div>
<a href="<?=$_SERVER['PHP_SELF'];?>?sort=true" class="sort">Sort Asc</a>
<a href="<?=$_SERVER['PHP_SELF'];?>?sort=false" class="sort">Sort Desc</a>

<?php

require_once "connect.php";
if(isset($_GET["sort"])){
	if ($_GET["sort"]=="true"){
		$sqlShowUsers = "SELECT * FROM users ORDER BY name";
	}
	else if ($_GET["sort"]=="false"){
		$sqlShowUsers = "SELECT * FROM users ORDER BY name DESC";
	}
}
else{
	$sqlShowUsers="SELECT * FROM users";
}

$resultShowUsers = mysqli_query($con, $sqlShowUsers);
?>
<table><tr><th>ID</th><th>Name</th><th>Surname</th><th>Username</th><th>Status</th><th>Options</th></tr>
<?php
foreach($resultShowUsers as $su){
?>
<tr>
	<td><?=$su['id']?></td>
	<td><?=$su['name']?></td>
	<td><?=$su['surname']?></td>
	<td><?=$su['username']?></td>
	<td><?=$su['status']?></td>
	<td><a href="vud.php?id=<?=$su['id']?>&opt=view">view</a> <a href="vud.php?id=<?=$su['id']?>&opt=update">update</a> <a href="vud.php?id=<?=$su['id']?>&opt=delete">delete</a></td>
</tr>
<?php
}
?>
</table>
</body>
</html>